If you don’t find the file after downloading, check your Downloads folder.
