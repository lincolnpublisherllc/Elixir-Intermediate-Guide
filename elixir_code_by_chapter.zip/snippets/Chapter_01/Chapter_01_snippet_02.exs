updated_person = %{person | age: 26}
