Functions are defined with the def keyword inside a module. A module is a container for related functions.
defmodule MyModule do
  def greet(name) do
    IO.puts("Hello, #{name}!")
  end
end
