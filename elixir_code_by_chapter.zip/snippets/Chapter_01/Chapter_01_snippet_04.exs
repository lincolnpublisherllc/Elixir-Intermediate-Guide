add = fn a, b -> a + b end
IO.puts(add.(3, 5))  # Output: 8
