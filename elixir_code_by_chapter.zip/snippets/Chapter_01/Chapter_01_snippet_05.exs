IO.puts(head)   # Output: 1
IO.inspect(tail) # Output: [2, 3]
