{status, name} = {:ok, "Alice"}
IO.puts(name)   # Output: Alice
1.5 Control Flow: if, case, and cond
