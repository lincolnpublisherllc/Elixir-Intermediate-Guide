IO.puts("5 is greater than 3")
