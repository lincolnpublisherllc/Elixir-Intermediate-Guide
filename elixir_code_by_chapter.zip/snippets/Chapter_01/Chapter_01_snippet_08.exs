IO.puts("5 is not greater than 3")
end
case Statements
case statements are useful for matching values against multiple patterns. You can think of them as a more powerful version of if/else chains.
case 2 do
  1 -> IO.puts("One")
  2 -> IO.puts("Two")
  _ -> IO.puts("Something else")
end
cond Statements
cond is similar to a series of if/else statements, but it allows for more readable, complex conditions.
cond do
  2 > 1 -> IO.puts("2 is greater than 1")
  3 > 1 -> IO.puts("3 is greater than 1")
  true -> IO.puts("This is the fallback")
end
