Mix is the build tool that comes with Elixir. It simplifies common tasks like:
