mix new my_project
