iex -S mix
