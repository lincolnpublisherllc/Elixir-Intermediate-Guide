defmodule MyProject.MixProject do
