def project do
    [
      app: :my_project,
      version: "0.1.0",
      elixir: "~> 1.12",
      deps: deps()
    ]
  end
