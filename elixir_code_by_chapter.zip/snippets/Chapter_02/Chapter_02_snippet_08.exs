defp deps do
    [
      {:ecto, "~> 3.6"},
      {:phoenix, "~> 1.5"}
    ]
  end
end
