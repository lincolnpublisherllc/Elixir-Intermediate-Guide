{:ecto, "~> 3.6"},
    {:phoenix, "~> 1.5"},
    {:httpoison, "~> 1.8"}
