MIX_ENV=dev mix run
