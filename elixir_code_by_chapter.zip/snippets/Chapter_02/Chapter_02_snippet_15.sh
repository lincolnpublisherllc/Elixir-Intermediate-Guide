MIX_ENV=prod mix run
