mix help
