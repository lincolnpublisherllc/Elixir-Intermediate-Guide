defmodule Math do
  def add(a, b) do
    a + b
  end
end
In this example, we define a function add/2 within the Math module. The def keyword begins the function definition, and the do block contains the body of the function.
