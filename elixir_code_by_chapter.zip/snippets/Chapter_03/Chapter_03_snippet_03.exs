add = fn a, b -> a + b end
IO.puts(add.(5, 3))  # Output: 8
