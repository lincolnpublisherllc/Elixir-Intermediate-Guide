defmodule Math do
  def add(a, b), do: a + b
  def subtract(a, b), do: a - b
end
