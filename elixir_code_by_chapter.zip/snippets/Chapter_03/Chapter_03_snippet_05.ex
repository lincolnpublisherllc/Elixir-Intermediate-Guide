defmodule Blog.Posts do
  def create_post(title, body), do: # logic for creating a post
  def list_posts(), do: # logic for listing posts
end
