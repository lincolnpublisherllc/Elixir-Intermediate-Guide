defmodule Blog.Comments do
  def add_comment(post_id, comment), do: # logic for adding a comment
  def list_comments(post_id), do: # logic for listing comments
end
