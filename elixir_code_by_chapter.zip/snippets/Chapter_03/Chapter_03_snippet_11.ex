# Bad Practice
defmodule Blog.Posts do
  def create_post(title, body, author) do
    # Creates post
    # Sends email
    # Updates cache
    # Log the action
  end
end
