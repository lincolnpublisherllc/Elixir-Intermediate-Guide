# Good Practice
defmodule Blog.Posts do
  def create_post(title, body, author) do
    post = create_new_post(title, body, author)
    send_creation_email(post)
    update_cache(post)
    log_post_creation(post)
  end
