defp create_new_post(title, body, author), do: # logic to create post
  defp send_creation_email(post), do: # logic to send email
  defp update_cache(post), do: # logic to update cache
  defp log_post_creation(post), do: # logic to log post creation
end
