defmodule Math do
  def operate(a, b, operation) do
    operation.(a, b)
  end
end
