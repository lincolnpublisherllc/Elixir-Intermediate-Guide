add = fn a, b -> a + b end
IO.puts(Math.operate(5, 3, add))  # Output: 8
