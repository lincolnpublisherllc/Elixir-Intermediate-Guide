4.2 Handling State with GenServer
As your application grows, you’ll often need to manage state. Elixir provides the GenServer (Generic Server) abstraction to handle stateful processes. A GenServer is a process that holds state and interacts with other processes.
defmodule Counter do
  use GenServer
