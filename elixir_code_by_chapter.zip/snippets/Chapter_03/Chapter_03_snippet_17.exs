def start_link(initial_value) do
    GenServer.start_link(__MODULE__, initial_value, name: :counter)
  end
