def increment(pid) do
    GenServer.cast(pid, :increment)
  end
