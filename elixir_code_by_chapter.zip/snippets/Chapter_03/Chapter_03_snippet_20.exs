def handle_cast(:increment, state) do
    {:noreply, state + 1}
  end
end
This simple Counter GenServer keeps track of a count and increments it each time increment/1 is called.
