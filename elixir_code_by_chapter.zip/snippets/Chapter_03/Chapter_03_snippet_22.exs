Use GenServer to manage the state of the task list.
