Leverage GenServer for managing state and handling concurrent operations.
