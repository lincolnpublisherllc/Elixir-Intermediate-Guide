defmodule Math do
  def sum_and_difference(a, b) do
    {a + b, a - b}  # Return a tuple with sum and difference
  end
end
