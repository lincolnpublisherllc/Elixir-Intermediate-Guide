IO.inspect(result)  # Output: {15, 5}
