IO.puts("Sum: #{sum}, Difference: #{difference}")
