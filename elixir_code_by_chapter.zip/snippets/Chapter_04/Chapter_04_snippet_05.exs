Maps are defined using the %{} syntax. Here’s an example of defining a map:
person = %{name: "Alice", age: 30, city: "New York"}
IO.inspect(person)
