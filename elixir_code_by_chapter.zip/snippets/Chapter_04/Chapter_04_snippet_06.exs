IO.puts(name)  # Output: Alice
IO.puts(city)  # Output: New York
