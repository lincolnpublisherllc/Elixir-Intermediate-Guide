person = %{person | age: 31}  # Update the age key
IO.inspect(person)  # Output: %{name: "Alice", age: 31, city: "New York"}
