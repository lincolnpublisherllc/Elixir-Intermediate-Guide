complex_map = %{{"apple", 1} => "fruit", 3 => "number"}
IO.inspect(complex_map)
