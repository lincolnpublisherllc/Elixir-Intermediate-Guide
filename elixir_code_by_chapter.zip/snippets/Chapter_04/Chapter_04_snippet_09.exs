set = MapSet.new([1, 2, 3, 3])  # Set automatically removes the duplicate 3
IO.inspect(set)  # Output: #MapSet<[1, 2, 3]>
You can perform set operations such as union, intersection, and difference using MapSet functions:
set1 = MapSet.new([1, 2, 3])
set2 = MapSet.new([3, 4, 5])
