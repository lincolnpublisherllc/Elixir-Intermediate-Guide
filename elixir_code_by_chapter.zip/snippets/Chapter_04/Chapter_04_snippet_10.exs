# Union of two sets
union = MapSet.union(set1, set2)
IO.inspect(union)  # Output: #MapSet<[1, 2, 3, 4, 5]>
