# Intersection of two sets
intersection = MapSet.intersection(set1, set2)
IO.inspect(intersection)  # Output: #MapSet<[3]>
