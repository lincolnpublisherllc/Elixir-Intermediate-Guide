def new(value), do: %Tree{value: value}
