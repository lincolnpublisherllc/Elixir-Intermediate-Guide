def insert(%Tree{value: nil} = tree, value), do: %Tree{tree | value: value}
  def insert(%Tree{value: value} = tree, new_value) when new_value < value do
    %Tree{tree | left: insert(tree.left || new(value), new_value)}
  end
  def insert(%Tree{value: value} = tree, new_value) when new_value > value do
    %Tree{tree | right: insert(tree.right || new(value), new_value)}
  end
end
