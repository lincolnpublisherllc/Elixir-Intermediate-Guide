defmodule TreeTraversal do
  def inorder(nil), do: []
  def inorder(%Tree{value: value, left: left, right: right}) do
    inorder(left) ++ [value] ++ inorder(right)
  end
end
