You can read files in Elixir using the File.read/1 function, which returns the file’s content as a string. If the file doesn’t exist, it returns an error tuple.
case File.read("example.txt") do
  {:ok, content} -> IO.puts("File content: #{content}")
  {:error, reason} -> IO.puts("Error: #{reason}")
end
If the file exists, File.read/1 returns an {:ok, content} tuple.
If the file doesn’t exist or an error occurs, it returns an {:error, reason} tuple.
