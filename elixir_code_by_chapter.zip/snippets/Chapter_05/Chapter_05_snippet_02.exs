You can write data to a file using File.write/2 or File.write/3. The first argument is the file name, the second is the content to be written, and the third is optional (for appending).
File.write("example.txt", "Hello, Elixir!")  # Overwrites the file
File.write("example.txt", "Appended text", [:append])  # Appends to the file
