|> Enum.each(fn line -> IO.puts(line) end)
