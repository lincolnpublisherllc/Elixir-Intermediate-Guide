You can decode JSON data using Jason.decode/1, which converts a JSON string into an Elixir data structure (like maps or lists).
