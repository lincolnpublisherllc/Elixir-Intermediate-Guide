{:ok, parsed_data} = Jason.decode(json)
IO.inspect(parsed_data)  # Output: %{"name" => "Alice", "age" => 30}
