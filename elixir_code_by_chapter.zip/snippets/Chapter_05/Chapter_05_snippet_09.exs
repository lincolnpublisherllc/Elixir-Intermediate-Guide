To encode Elixir data structures into JSON, use Jason.encode/1:
data = %{"name" => "Alice", "age" => 30}
{:ok, json_string} = Jason.encode(data)
IO.puts(json_string)  # Output: "{\"name\":\"Alice\",\"age\":30}"
