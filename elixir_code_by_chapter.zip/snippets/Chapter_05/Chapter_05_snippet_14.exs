Here’s how you can parse a CSV file line by line using NimbleCSV:
NimbleCSV.define(MyCSVParser, separator: ",", escape: "\"")
