|> MyCSVParser.parse_stream()
|> Enum.each(fn [name, age] -> IO.puts("#{name} is #{age} years old") end)
