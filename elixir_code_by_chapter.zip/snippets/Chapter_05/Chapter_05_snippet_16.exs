You can also use NimbleCSV to generate CSV data from Elixir data structures:
