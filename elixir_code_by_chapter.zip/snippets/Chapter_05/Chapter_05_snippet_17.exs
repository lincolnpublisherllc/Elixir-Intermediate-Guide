csv_string = NimbleCSV.RFC4180.dump(data)
IO.puts(csv_string)
