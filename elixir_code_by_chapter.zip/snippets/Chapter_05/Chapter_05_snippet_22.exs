Use SweetXml to parse and navigate XML documents:
