{:ok, parsed_xml} = SweetXml.parse(xml)
name = SweetXml.xpath(parsed_xml, ~x"//name/text()")
IO.puts("Name: #{name}")
