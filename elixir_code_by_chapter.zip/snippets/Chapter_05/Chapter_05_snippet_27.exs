{:ok, response} = HTTPoison.get("https://jsonplaceholder.typicode.com/posts/1")
IO.inspect(response.body)
