HTTPoison returns different types of responses (e.g., {:ok, response} or {:error, reason}). You can match on the result to handle successful and failed requests:
case HTTPoison.get("https://jsonplaceholder.typicode.com/posts/1") do
  {:ok, response} -> IO.inspect(response.body)
  {:error, reason} -> IO.puts("Error: #{reason}")
end
