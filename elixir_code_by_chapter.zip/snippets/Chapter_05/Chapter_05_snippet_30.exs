Use try, catch, and rescue to gracefully handle errors when working with files.
try do
  File.read!("non_existent_file.txt")
rescue
  exception in File.Error -> IO.puts("File not found!")
end
