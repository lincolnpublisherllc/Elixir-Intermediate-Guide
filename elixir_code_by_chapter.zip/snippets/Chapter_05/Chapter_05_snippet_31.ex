defmodule Retry do
  def request_with_retry(url, retries \\ 3) do
    case HTTPoison.get(url) do
      {:ok, response} -> {:ok, response}
      {:error, _reason} when retries > 0 ->
        IO.puts("Retrying... #{retries} left")
        :timer.sleep(1000)  # Wait 1 second before retrying
        request_with_retry(url, retries - 1)
      {:error, reason} -> {:error, reason}
    end
  end
end
