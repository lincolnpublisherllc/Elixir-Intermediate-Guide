Parses the CSV file (use NimbleCSV).
