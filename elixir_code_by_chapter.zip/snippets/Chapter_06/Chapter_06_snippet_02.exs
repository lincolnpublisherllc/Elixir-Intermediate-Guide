1.2 Using try, catch, and rescue
Elixir uses the try, catch, and rescue constructs to handle errors. These constructs provide ways to trap errors, handle exceptions, and perform cleanup tasks.
try and catch are used for low-level exception handling.
rescue is used to handle specific exceptions, especially in functions that might fail.
1.3 Basic Error Handling with try and catch
try is used to execute code that might raise an exception, and catch is used to catch the exception.
try do
  # Code that might raise an error
