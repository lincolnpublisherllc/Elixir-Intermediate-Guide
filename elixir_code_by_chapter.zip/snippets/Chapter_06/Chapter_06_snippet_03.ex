catch
  :error, reason -> IO.puts("Caught an error: #{reason}")
end
In this example, the division by zero raises an error, which is caught and handled by the catch block. The :error atom tells Elixir to match the error type, and the reason variable will hold the error message.
1.4 Using rescue for Specific Exceptions
rescue is used to handle specific exceptions in a function. This is typically used in functions that might throw an error under normal circumstances (e.g., I/O operations, database queries).
defmodule MyModule do
  def divide(a, b) do
    try do
      a / b
    rescue
      ArithmeticError -> IO.puts("Division by zero error!")
    end
  end
end
