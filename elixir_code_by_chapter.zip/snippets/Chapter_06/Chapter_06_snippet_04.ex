You can rescue multiple types of exceptions in a single rescue block. This is useful when a function might raise different exceptions, and you want to handle them in a generic way.
defmodule MyModule do
  def handle_error(value) do
    try do
      String.to_integer(value)
    rescue
      ArgumentError -> IO.puts("Invalid argument!")
      FunctionClauseError -> IO.puts("Function clause error!")
    end
  end
end
In this case, if String.to_integer/1 fails due to an invalid argument (like "abc"), the ArgumentError exception is rescued, and a custom message is displayed.
1.6 Using after for Cleanup
You can use after in a try block to perform cleanup tasks, no matter whether the code inside the try block succeeds or fails.
try do
  IO.puts("Doing something risky...")
