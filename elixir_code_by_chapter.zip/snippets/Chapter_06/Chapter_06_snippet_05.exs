after
  IO.puts("Cleaning up resources...")
end
