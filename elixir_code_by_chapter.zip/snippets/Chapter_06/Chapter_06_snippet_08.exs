assert 2 + 3 == 5  # This test passes
  end
end
