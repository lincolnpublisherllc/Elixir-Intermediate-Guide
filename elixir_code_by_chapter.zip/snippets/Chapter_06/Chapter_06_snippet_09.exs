test is used to define a test case, which contains assertions about expected outcomes. In this case, we are testing that 2 + 3 equals 5.
