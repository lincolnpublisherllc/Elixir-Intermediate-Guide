ExUnit also allows you to run code before and after each test. This is useful when you need to set up resources (like database connections) or clean up after tests.
defmodule MyModuleTest do
