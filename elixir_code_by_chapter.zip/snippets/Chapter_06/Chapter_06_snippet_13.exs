# Code to set up before each test
    {:ok, conn: "database connection"}
  end
