test "adding two numbers", %{conn: conn} do
    assert 2 + 3 == 5
    assert conn == "database connection"  # Example use of setup data
  end
end
