The test can then access the conn value using the %{} syntax.
