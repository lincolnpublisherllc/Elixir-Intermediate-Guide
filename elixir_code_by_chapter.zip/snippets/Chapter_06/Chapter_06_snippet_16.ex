3.1 Debugging with IO.inspect
The most common method of debugging in Elixir is IO.inspect/2, which prints variables to the console. This is especially useful when you need to inspect the values of variables or data structures.
defmodule MyModule do
  def add(a, b) do
    IO.inspect(a, label: "First operand")
    IO.inspect(b, label: "Second operand")
    a + b
  end
end
IO.inspect/2 can also accept options like label to provide context for the output.
