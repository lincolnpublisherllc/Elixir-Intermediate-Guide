defmodule MyModule do
  def divide(a, 0), do: raise "Cannot divide by zero"
  def divide(a, b), do: a / b
end
In this example, raise throws an exception if the denominator is zero, allowing you to catch the error in your application.
