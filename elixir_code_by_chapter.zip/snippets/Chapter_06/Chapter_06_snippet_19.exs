Logger.debug("Debugging variable x: #{inspect(x)}")
Logger.info("Task completed successfully.")
Logger.error("An error occurred: #{inspect(error)}")
