How to handle errors using try, catch, rescue, and after.
