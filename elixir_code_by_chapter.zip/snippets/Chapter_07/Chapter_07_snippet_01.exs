The tools and constructs Elixir provides to manage concurrency, such as GenServer, Task, and Agent.
