spawn(fn -> IO.puts("Hello from the new process!") end)
