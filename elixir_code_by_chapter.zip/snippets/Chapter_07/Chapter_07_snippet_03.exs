pid = spawn(fn -> receive do
  message -> IO.puts("Received message: #{message}")
