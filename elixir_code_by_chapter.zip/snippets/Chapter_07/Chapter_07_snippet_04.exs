:ping -> IO.puts("Received ping!")
  :stop -> IO.puts("Stopping process")
  _ -> IO.puts("Unknown message")
end
In this example, the process checks the message type and processes it accordingly. The underscore (_) is used as a wildcard to catch any other messages.
