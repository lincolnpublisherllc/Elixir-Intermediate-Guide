Step 3: Managing Concurrency with GenServer
3.1 What is GenServer?
Elixir’s GenServer (Generic Server) is a powerful abstraction that simplifies writing concurrent, stateful processes. It is the building block for many Elixir libraries and frameworks, including Phoenix.
A GenServer is a process that maintains state and responds to messages. It follows a specific set of callbacks that you implement, such as handle_call/3 for synchronous requests and handle_cast/2 for asynchronous requests.
3.2 Defining a GenServer
To define a GenServer, you use the GenServer module and implement the necessary callbacks.
defmodule Counter do
  use GenServer
