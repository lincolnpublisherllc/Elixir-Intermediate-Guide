def get_value(pid) do
    GenServer.call(pid, :get_value)
  end
