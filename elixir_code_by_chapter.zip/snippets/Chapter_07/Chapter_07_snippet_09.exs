# Server callbacks
  def init(initial_value) do
    {:ok, initial_value}
  end
