def handle_cast(:increment, state) do
    {:noreply, state + 1}
  end
