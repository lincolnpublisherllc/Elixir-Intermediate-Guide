def handle_call(:get_value, _from, state) do
    {:reply, state, state}
  end
end
start_link/1: Starts the GenServer process with an initial value.
increment/1: Sends an asynchronous message to the GenServer to increment its state.
