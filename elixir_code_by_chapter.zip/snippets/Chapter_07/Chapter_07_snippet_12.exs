3.3 Starting and Interacting with GenServer
To interact with the GenServer, use the client functions:
{:ok, pid} = Counter.start_link(0)  # Start the GenServer with initial value 0
