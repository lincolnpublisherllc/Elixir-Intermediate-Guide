GenServer.call/2 and GenServer.cast/2 are the two primary ways to interact with GenServers:
