Step 4: Parallelism with Task and Agent
4.1 Parallelism with Task
Elixir provides the Task module to run functions in parallel. A Task is a lightweight process that runs a function asynchronously and allows you to wait for the result.
task = Task.async(fn -> 1 + 2 end)
IO.puts("The result is #{Task.await(task)}")  # Output: The result is 3
Task.async/1 spawns a new process to run the function.
Task.await/1 waits for the result of the task.
