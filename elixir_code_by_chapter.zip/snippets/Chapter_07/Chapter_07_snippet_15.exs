4.2 Using Agent for State Management
Agent is a simple abstraction for managing state in a process. It is useful when you need a shared state but don’t want to manage the complexities of GenServer.
defmodule MyAgent do
  use Agent
