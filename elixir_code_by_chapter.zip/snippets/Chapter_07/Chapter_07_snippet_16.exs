def start_link(initial_value) do
    Agent.start_link(fn -> initial_value end, name: :my_agent)
  end
