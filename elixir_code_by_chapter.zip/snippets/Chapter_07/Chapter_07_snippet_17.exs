def get_value do
    Agent.get(:my_agent, fn state -> state end)
  end
