def set_value(value) do
    Agent.update(:my_agent, fn _ -> value end)
  end
end
Agent.start_link/2: Starts an agent with an initial state.
Agent.get/2: Retrieves the state.
Agent.update/2: Updates the state.
