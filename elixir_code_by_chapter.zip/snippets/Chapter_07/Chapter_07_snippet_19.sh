iex --sname node1 -setcookie mycookie
iex --sname node2 -setcookie mycookie
