Challenge: Implement a parallel file processing system. Write a program that reads multiple files concurrently, processes them in parallel using Task, and outputs the results.
