How to use GenServer for stateful, concurrent processes.
The use of Task for parallelism and Agent for managing shared state.
