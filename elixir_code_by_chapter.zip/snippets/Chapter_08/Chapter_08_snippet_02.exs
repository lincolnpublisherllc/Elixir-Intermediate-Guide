def start_engine(%Car{make: make, model: model}) do
    IO.puts("#{make} #{model} engine started.")
  end
end
