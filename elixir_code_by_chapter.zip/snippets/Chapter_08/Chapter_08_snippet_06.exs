def print(%Car{make: make, model: model, year: year}) do
    IO.puts("Car: #{make} #{model}, #{year}")
  end
end
