def print(string) do
    IO.puts("String: #{string}")
  end
end
