multiply = fn a, b -> a * b end
IO.puts(multiply.(3, 4))  # Output: 12
