defmodule MyModule do
  def sum_list([head | tail]), do: head + sum_list(tail)
  def sum_list([]), do: 0  # Base case
end
