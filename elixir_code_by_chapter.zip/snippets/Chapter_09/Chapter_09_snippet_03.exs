defp deps do
    [
      {:httpoison, "~> 1.8"}
    ]
  end
end
