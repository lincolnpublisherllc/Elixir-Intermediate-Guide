defmodule MyApp.FetchData do
  def get_data do
    {:ok, response} = HTTPoison.get("https://jsonplaceholder.typicode.com/posts")
    IO.puts(response.body)
  end
end
