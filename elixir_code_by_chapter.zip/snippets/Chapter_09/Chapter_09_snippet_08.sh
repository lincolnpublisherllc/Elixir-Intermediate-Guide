mix phx.new my_app
