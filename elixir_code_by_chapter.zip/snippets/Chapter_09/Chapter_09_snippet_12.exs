def join("room:lobby", _message, socket) do
    {:ok, socket}
  end
end
