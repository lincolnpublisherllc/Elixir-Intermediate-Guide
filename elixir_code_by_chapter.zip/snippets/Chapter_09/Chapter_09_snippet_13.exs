2.2 Ecto (Database Interaction)
Ecto is the official Elixir library for interacting with databases. It provides a powerful query language and works seamlessly with Phoenix.
Setting up Ecto:
Add Ecto and a database adapter (e.g., Postgrex for PostgreSQL) to your dependencies:
defp deps do
