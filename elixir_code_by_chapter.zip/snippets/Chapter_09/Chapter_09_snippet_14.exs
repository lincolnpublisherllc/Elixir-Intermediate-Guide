{:ecto_sql, "~> 3.5"},
    {:postgrex, ">= 0.0.0"}
