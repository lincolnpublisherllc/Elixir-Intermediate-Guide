Ecto uses schemas to represent your database tables. A schema maps a struct to a table in the database.
defmodule MyApp.Post do
  use Ecto.Schema
