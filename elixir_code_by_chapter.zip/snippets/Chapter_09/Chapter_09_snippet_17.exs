field :title, :string
    field :content, :string
  end
end
