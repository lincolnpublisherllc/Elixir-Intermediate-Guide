Ecto provides a powerful query DSL that allows you to build complex queries:
MyApp.Repo.all(from p in MyApp.Post, where: p.title == "Elixir", select: p)
