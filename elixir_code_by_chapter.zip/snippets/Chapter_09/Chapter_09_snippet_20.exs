{:ok, response} = HTTPoison.get("https://jsonplaceholder.typicode.com/posts")
IO.puts(response.body)
