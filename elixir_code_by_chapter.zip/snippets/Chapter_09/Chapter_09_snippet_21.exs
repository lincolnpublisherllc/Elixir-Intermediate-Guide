{:ok, response} = HTTPoison.post("https://jsonplaceholder.typicode.com/posts", "{\"title\": \"New Post\"}", [{"Content-Type", "application/json"}])
IO.puts(response.body)
