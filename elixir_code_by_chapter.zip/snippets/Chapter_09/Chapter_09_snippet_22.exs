defmodule MyAppWeb.Plugs.CheckAuth do
