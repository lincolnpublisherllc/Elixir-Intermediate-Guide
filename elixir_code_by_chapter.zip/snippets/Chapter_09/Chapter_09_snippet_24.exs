def call(conn, _opts) do
    if get_session(conn, :user_id) do
      conn
    else
      conn |> send_resp(403, "Forbidden") |> halt()
    end
  end
end
