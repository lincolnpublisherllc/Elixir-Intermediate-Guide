def run(_args) do
    IO.puts("Hello, Elixir!")
  end
end
