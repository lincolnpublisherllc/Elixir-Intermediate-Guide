def run_benchmark do
    Benchee.run(%{
      "factorial" => fn -> factorial(100) end
    })
  end
