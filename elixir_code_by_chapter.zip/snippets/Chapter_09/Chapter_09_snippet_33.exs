IO.inspect(some_function())
