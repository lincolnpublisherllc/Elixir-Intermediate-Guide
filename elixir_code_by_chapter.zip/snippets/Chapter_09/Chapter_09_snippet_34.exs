Popular Elixir libraries like Phoenix, Ecto, HTTPoison, and Plug, and how to use them to build scalable applications.
