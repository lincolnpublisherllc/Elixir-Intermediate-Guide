mix archive.install hex phx_new 1.6.0
