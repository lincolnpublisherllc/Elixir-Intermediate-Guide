mix phx.new todo_api --no-ecto --no-html --no-dashboard
