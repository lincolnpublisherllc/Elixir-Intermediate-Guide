This will create a new project without Ecto (the database library) and HTML support, focusing purely on the API.
