# In-memory storage for tasks
  defp tasks do
    %{
      1 => %{id: 1, name: "Learn Elixir", completed: false},
      2 => %{id: 2, name: "Build a Phoenix API", completed: false}
    }
  end
