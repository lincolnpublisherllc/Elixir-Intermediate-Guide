def index(conn, _params) do
    # Get all tasks and render them as JSON
    tasks = tasks() |> Map.values()
    json(conn, tasks)
  end
