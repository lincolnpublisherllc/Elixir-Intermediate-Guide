def show(conn, %{"id" => id}) do
    # Get a single task by ID
    task = Map.get(tasks(), String.to_integer(id))
