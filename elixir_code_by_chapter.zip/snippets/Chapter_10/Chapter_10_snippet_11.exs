if task do
      json(conn, task)
    else
      send_resp(conn, :not_found, "Task not found")
    end
  end
