def create(conn, %{"name" => name}) do
    # Create a new task (mock implementation)
    task = %{id: 3, name: name, completed: false}
    json(conn, task)
  end
