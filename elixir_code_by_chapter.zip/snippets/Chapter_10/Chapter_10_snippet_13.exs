def update(conn, %{"id" => id, "name" => name}) do
    # Update an existing task (mock implementation)
    task = %{id: String.to_integer(id), name: name, completed: false}
    json(conn, task)
  end
