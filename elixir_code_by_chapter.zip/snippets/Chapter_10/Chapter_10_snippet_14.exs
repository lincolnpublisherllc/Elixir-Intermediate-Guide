def delete(conn, %{"id" => id}) do
    # Delete a task by ID (mock implementation)
    send_resp(conn, :no_content, "")
  end
end
