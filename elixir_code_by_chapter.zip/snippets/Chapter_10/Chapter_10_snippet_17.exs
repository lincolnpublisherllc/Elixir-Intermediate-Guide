resources "/tasks", TaskController, except: [:new, :edit]
  end
end
