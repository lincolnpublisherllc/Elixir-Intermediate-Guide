def create(conn, %{"name" => name}) do
    if String.length(name) < 3 do
      send_resp(conn, :bad_request, "Name too short")
    else
      task = %{id: 3, name: name, completed: false}
      json(conn, task)
    end
  end
end
