test "GET /api/tasks returns all tasks", %{conn: conn} do
    conn = get(conn, "/api/tasks")
    assert json_response(conn, 200)["id"]
  end
