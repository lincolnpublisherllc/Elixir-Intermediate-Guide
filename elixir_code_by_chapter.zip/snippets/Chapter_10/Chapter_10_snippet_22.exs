test "POST /api/tasks creates a task", %{conn: conn} do
    conn = post(conn, "/api/tasks", %{name: "New Task"})
    assert json_response(conn, 200)["name"] == "New Task"
  end
end
