mix phx.gen.repo -r MyApp.Repo
