Ecto uses migrations to manage changes to your database schema. To generate a migration, run:
