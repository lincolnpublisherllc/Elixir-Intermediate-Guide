mix ecto.gen.migration create_users
