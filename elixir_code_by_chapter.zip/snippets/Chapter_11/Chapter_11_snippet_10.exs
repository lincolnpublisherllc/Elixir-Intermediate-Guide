defmodule MyApp.Repo.Migrations.CreateUsers do
  use Ecto.Migration
