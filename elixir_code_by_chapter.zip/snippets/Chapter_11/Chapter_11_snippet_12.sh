mix ecto.migrate
