To define a schema that maps to a table in your database, you’ll need to create a module with the Ecto.Schema macro:
defmodule MyApp.User do
  use Ecto.Schema
  import Ecto.Changeset
