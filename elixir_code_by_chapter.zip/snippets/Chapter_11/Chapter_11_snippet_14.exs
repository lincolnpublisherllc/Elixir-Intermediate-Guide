field :name, :string
    field :email, :string
    timestamps()
  end
