1.4 Querying the Database with Ecto
Ecto provides a powerful query DSL to interact with the database. Here’s an example of querying for all users:
users = MyApp.Repo.all(MyApp.User)
IO.inspect(users)
