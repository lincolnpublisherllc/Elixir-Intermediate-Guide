IO.inspect(MyApp.Repo.all(users))
