You can insert or update data using Ecto’s Repo.insert/2 and Repo.update/2 functions:
# Inserting a new user
