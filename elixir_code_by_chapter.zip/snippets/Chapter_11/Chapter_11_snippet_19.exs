MyApp.Repo.insert!(user)
