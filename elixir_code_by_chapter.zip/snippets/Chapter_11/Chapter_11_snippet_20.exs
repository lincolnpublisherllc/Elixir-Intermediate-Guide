# Updating a user
user = MyApp.Repo.get(MyApp.User, 1)
changeset = MyApp.User.changeset(user, %{email: "new_email@example.com"})
MyApp.Repo.update!(changeset)
