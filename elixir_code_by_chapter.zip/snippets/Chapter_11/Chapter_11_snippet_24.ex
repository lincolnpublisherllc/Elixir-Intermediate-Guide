defmodule MyApp.ApiClient do
  def get_data do
    {:ok, response} = HTTPoison.get("https://jsonplaceholder.typicode.com/posts")
    IO.inspect(response.body)
  end
end
