defmodule MyApp.ApiClient do
  def post_data do
    body = "{\"title\": \"New Post\"}"
    {:ok, response} = HTTPoison.post("https://jsonplaceholder.typicode.com/posts", body, [{"Content-Type", "application/json"}])
    IO.inspect(response.body)
  end
end
