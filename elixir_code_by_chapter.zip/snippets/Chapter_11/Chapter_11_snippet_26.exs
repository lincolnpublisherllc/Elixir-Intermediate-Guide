The response from HTTPoison is a tuple {:ok, response} or {:error, reason}. You can match on this tuple to handle the response appropriately:
case HTTPoison.get("https://jsonplaceholder.typicode.com/posts") do
  {:ok, response} -> IO.puts("Received data: #{response.body}")
  {:error, reason} -> IO.puts("Error: #{reason}")
end
