{:ok, response} = HTTPoison.get("https://api.example.com/data", headers)
