def perform(%Oban.Job{args: %{"email" => email}}) do
    IO.puts("Sending email to #{email}")
  end
end
