MyApp.Repo.insert!(%MyApp.Jobs.SendEmail{args: %{"email" => "user@example.com"}})
