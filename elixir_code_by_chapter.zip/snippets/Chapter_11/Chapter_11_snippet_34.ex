Elixir makes it easy to connect to and interact with external databases like PostgreSQL, MySQL, or MongoDB. You can use Ecto to interface with these databases and perform operations such as queries, inserts, and updates.
For example, to interact with a PostgreSQL database, you can configure Ecto with the PostgreSQL adapter:
defmodule MyApp.Repo do
  use Ecto.Repo, otp_app: :my_app, adapter: Ecto.Adapters.Postgres
end
Then, you can interact with the database through Ecto, just like we’ve already covered in previous chapters.
