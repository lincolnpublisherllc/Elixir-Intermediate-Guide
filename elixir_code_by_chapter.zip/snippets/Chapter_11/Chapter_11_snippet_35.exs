Stores the data in a database using Ecto.
