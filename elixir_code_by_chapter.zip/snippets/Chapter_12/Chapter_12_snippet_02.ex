defmodule MyModule do
  def process_data(data) do
    data
    |> Enum.chunk_every(100)
    |> Enum.each(fn chunk -> Task.async(fn -> process_chunk(chunk) end) end)
  end
