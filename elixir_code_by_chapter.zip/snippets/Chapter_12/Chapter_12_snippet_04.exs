:sys.get_state/1:
This function allows you to examine the internal state of processes, including GenServer and other processes. You can use this to monitor how much memory a specific process is using.
{:ok, state} = :sys.get_state(pid)
IO.inspect(state)
