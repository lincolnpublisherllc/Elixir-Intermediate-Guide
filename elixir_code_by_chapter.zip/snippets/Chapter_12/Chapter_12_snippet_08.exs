Limit process state. Use GenServer to limit the state kept in memory and clean up state when it’s no longer needed.
