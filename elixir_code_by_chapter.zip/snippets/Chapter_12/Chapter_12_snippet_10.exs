defp process_chunk(chunk) do
    # Process chunk in parallel
  end
end
Use Task.Supervisor for Managing Tasks:
The Task.Supervisor module allows you to manage a set of tasks, ensuring that they are supervised and any failures are handled appropriately.
{:ok, supervisor_pid} = Task.Supervisor.start_link(name: MyApp.TaskSupervisor)
Task.Supervisor.async(supervisor_pid, fn -> some_task() end)
