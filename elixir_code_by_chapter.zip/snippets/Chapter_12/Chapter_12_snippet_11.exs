Use Task.async and Task.await to execute tasks concurrently and await their results when needed.
