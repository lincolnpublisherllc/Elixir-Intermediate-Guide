{:ok, value} = :ets.lookup(:my_table, :key)
IO.puts(value)  # Output: "value"
