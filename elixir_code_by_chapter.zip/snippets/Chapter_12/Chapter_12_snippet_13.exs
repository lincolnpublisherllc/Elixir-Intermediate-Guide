Challenge: Write an Elixir application that reads a large file, processes it in parallel using Task.async to count the occurrences of each word, and outputs the result.
