Best practices for handling concurrency efficiently using processes, Task, and GenServer.
