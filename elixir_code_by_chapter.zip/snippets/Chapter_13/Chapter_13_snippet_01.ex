defmodule MyModule do
  def my_function() do
    IO.puts("Hello, Elixir!")
  end
end
