case {x, y} do
  {x, y} when x > 5 and y > 3 -> # Do something
  _ -> :nothing
end
