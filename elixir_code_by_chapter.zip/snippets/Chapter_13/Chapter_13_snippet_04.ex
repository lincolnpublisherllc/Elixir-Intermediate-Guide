defmodule MyModule do
  def process_data(data) do
    data
    |> validate()
    |> transform()
    |> format()
    |> save_to_database()
  end
end
