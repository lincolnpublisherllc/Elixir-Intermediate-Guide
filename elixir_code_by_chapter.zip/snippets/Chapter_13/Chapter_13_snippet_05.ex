defmodule MyModule do
  def process_data(data) do
    data
    |> validate()
    |> transform_data()
    |> format_for_display()
    |> save_to_db()
  end
