defmodule MyModule do
  def check_status(:ok), do: IO.puts("Everything is fine!")
  def check_status(:error), do: IO.puts("Something went wrong!")
  def check_status(_), do: IO.puts("Unknown status!")
end
