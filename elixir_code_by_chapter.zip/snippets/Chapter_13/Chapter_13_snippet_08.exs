You, as a developer, remember how your code works after a period of time.
