defmodule UserManager do
  # Module code goes here
end
