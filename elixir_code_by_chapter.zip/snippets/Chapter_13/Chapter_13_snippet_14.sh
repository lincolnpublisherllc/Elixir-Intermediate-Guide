mix docs
