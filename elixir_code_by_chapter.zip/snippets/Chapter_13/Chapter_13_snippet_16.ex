defmodule UserManager.Accounts do
  def create_user(attrs), do: # account creation logic
  def update_user(id, attrs), do: # account update logic
end
