defmodule UserManager.Authentication do
  def authenticate_user(credentials), do: # authentication logic
end
