assert MyModule.add(1, 2) == 3
  end
end
