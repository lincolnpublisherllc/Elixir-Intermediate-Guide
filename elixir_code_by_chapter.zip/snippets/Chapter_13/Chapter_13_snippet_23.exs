Use GenServer to manage user data.
