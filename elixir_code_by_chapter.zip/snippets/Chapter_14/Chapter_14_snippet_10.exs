Use Ecto to create and manage the database schema for tasks and users.
