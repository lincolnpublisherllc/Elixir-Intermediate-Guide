mix phx.new todo_app --no-html --no-webpack --no-dashboard --no-ecto
