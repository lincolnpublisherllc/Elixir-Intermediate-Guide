def handle_in("update_task", %{"id" => id, "status" => status}, socket) do
    broadcast!(socket, "task_updated", %{"id" => id, "status" => status})
    {:noreply, socket}
  end
end
Background Jobs for Notifications:
Use Oban or Task.async for sending asynchronous notifications. For instance, send a task reminder when the task’s due date is approaching.
