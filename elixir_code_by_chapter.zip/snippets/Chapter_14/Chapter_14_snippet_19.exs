Ecto for database integration and queries.
